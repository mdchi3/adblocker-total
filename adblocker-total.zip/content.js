// Content Script: Limpieza DOM en tiempo real, bloqueo de popups/redirecciones y auto-skip de ads de video
(() => {
  let isEnabled = true;

  // Consultar configuración
  chrome.storage.local.get(['adblockerEnabled'], (res) => {
    if (res && res.adblockerEnabled === false) {
      isEnabled = false;
    }
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.adblockerEnabled) {
      isEnabled = changes.adblockerEnabled.newValue;
    }
  });

  const adSelectors = [
    'ins.adsbygoogle',
    'iframe[src*="doubleclick.net"]',
    'iframe[src*="googlesyndication.com"]',
    'iframe[src*="googleadservices.com"]',
    'iframe[src*="criteo.com"]',
    'iframe[src*="taboola.com"]',
    'iframe[src*="outbrain.com"]',
    'iframe[src*="adnxs.com"]',
    'iframe[src*="smartadserver.com"]',
    'iframe[src*="rubiconproject.com"]',
    'iframe[src*="openx.net"]',
    'iframe[id*="google_ads_iframe"]',
    'div[id*="google_ads_iframe"]',
    'div[id*="div-gpt-ad"]',
    'div[id*="dfp-ad"]',
    'div[class*="adsbygoogle"]',
    'div[class*="ad-banner"]',
    'div[class*="banner-ad"]',
    'div[class*="ads-container"]',
    'div[class*="ad-slot"]',
    'div[class*="ad-wrapper"]',
    '.ad-slot',
    '.ad-container',
    '.advertisement',
    '.sponsored-post',
    '.sponsored-ad',
    '.publicidad',
    '.anuncio',
    '[data-ad-client]',
    '[data-ad-slot]',
    '[data-adunit]',
    '[data-google-query-id]',
    'ytd-ad-slot-renderer',
    'ytd-display-ad-renderer',
    'ytd-promoted-sparkles-web-renderer',
    'ytd-in-feed-ad-layout-renderer',
    '#masthead-ad',
    '#player-ads'
  ];

  function removeAds() {
    if (!isEnabled) return;
    try {
      const elements = document.querySelectorAll(adSelectors.join(','));
      let removedThisCycle = 0;

      for (let i = 0; i < elements.length; i++) {
        const el = elements[i];
        if (el && el.parentNode && !el.dataset.adblockerChecked) {
          el.dataset.adblockerChecked = "true";
          el.remove();
          removedThisCycle++;
        }
      }

      if (removedThisCycle > 0) {
        chrome.runtime.sendMessage({ action: 'INCREMENT_BLOCKED_COUNT', count: removedThisCycle }).catch(() => {});
      }

      // Auto-saltar anuncios en reproductores de video (ej. YouTube)
      const skipBtn = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button');
      if (skipBtn) {
        skipBtn.click();
        chrome.runtime.sendMessage({ action: 'INCREMENT_BLOCKED_COUNT', count: 1 }).catch(() => {});
      }

      // Si hay un anuncio activo en video, adelantarlo al final instantáneamente
      const adPlayerOverlay = document.querySelector('.ad-showing, .ad-interrupting');
      if (adPlayerOverlay) {
        const video = document.querySelector('video');
        if (video && !isNaN(video.duration) && isFinite(video.duration)) {
          video.currentTime = video.duration;
          if (skipBtn) skipBtn.click();
        }
      }
    } catch (e) {
      // Ignorar errores en páginas restringidas
    }
  }

  // Ejecutar periódicamente y con MutationObserver
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', removeAds);
  } else {
    removeAds();
  }

  const observer = new MutationObserver(() => {
    if (!isEnabled) return;
    removeAds();
  });

  observer.observe(document.documentElement || document.body, {
    childList: true,
    subtree: true
  });

  // Chequeo por intervalos para anuncios insertados con retraso
  setInterval(removeAds, 1000);
})();
