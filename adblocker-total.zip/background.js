// Service worker para contabilizar bloqueos por pestaña activa (primer plano) y acumulados
let tabBlockedCounts = {}; // { [tabId]: count }
let totalBlocked = 0;
let isEnabled = true;

// Cargar estadísticas
chrome.storage.local.get(['totalBlocked', 'adblockerEnabled'], (res) => {
  if (res && typeof res.totalBlocked === 'number') {
    totalBlocked = res.totalBlocked;
  }
  isEnabled = res ? res.adblockerEnabled !== false : true;
  updateActiveTabBadge();
});

// Función para formatear el texto del badge
function formatBadgeText(count) {
  if (!count || count <= 0) return '';
  if (count > 999) return `${(count / 1000).toFixed(1)}k`;
  return `${count}`;
}

// Actualiza el badge del icono EXCLUSIVAMENTE para una pestaña dada
function updateTabBadge(tabId) {
  if (!tabId || tabId < 0) return;

  if (!isEnabled) {
    chrome.action.setBadgeText({ tabId: tabId, text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#64748b' });
    return;
  }

  const count = tabBlockedCounts[tabId] || 0;
  const text = formatBadgeText(count);
  chrome.action.setBadgeText({ tabId: tabId, text: text });
  chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#2563eb' });
}

// Actualiza el badge de la pestaña en primer plano
function updateActiveTabBadge() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    if (tabs && tabs.length > 0 && tabs[0].id) {
      updateTabBadge(tabs[0].id);
    }
  });
}

// Escuchar cambios de pestaña activa
chrome.tabs.onActivated.addListener((activeInfo) => {
  updateTabBadge(activeInfo.tabId);
});

// Cuando se inicia la carga de una nueva página en una pestaña, reiniciar su contador
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    tabBlockedCounts[tabId] = 0;
    updateTabBadge(tabId);
  }
});

// Limpiar cuando se cierra una pestaña
chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabBlockedCounts[tabId];
});

// Intercepción por DeclarativeNetRequest Feedback (si está en modo unpacked/debug)
if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    const tabId = (info.request && typeof info.request.tabId === 'number') ? info.request.tabId : -1;
    if (tabId > 0) {
      tabBlockedCounts[tabId] = (tabBlockedCounts[tabId] || 0) + 1;
      updateTabBadge(tabId);
    }
    totalBlocked++;
    chrome.storage.local.set({ totalBlocked });
  });
}

// Mensajería
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'INCREMENT_BLOCKED_COUNT') {
    const tabId = (sender.tab && sender.tab.id) ? sender.tab.id : null;
    const added = message.count || 1;

    totalBlocked += added;
    chrome.storage.local.set({ totalBlocked });

    if (tabId) {
      tabBlockedCounts[tabId] = (tabBlockedCounts[tabId] || 0) + added;
      updateTabBadge(tabId);
      sendResponse({ success: true, tabCount: tabBlockedCounts[tabId], totalBlocked });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          const activeId = tabs[0].id;
          tabBlockedCounts[activeId] = (tabBlockedCounts[activeId] || 0) + added;
          updateTabBadge(activeId);
        }
      });
      sendResponse({ success: true, totalBlocked });
    }
    return true;
  }

  // Obtener estadísticas de la página en primer plano y acumulados
  if (message.action === 'GET_STATS') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTabId = (tabs && tabs.length > 0) ? tabs[0].id : null;
      const pageBlocked = activeTabId ? (tabBlockedCounts[activeTabId] || 0) : 0;

      sendResponse({
        pageBlocked: pageBlocked,
        totalBlocked: totalBlocked,
        enabled: isEnabled
      });
    });
    return true;
  }

  // Activar o desactivar el bloqueador
  if (message.action === 'TOGGLE_ADBLOCKER') {
    isEnabled = !isEnabled;
    chrome.storage.local.set({ adblockerEnabled: isEnabled }, () => {
      chrome.declarativeNetRequest.updateEnabledRulesets({
        [isEnabled ? 'enableRulesetIds' : 'disableRulesetIds']: ['ruleset_ads']
      }).catch(() => {});

      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(t => updateTabBadge(t.id));
      });

      sendResponse({ enabled: isEnabled });
    });
    return true;
  }
});
