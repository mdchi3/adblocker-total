document.addEventListener('DOMContentLoaded', () => {
  const powerToggle = document.getElementById('powerToggle');
  const statusDesc = document.getElementById('statusDesc');
  const pageBlockedCount = document.getElementById('pageBlockedCount');
  const totalBlockedCount = document.getElementById('totalBlockedCount');

  function updateUI(enabled, pageCount, totalCount) {
    powerToggle.checked = enabled;
    pageBlockedCount.textContent = (pageCount || 0).toLocaleString();
    if (totalBlockedCount) {
      totalBlockedCount.textContent = (totalCount || 0).toLocaleString();
    }

    if (enabled) {
      statusDesc.textContent = 'Activa en esta página';
      statusDesc.className = 'status-desc';
    } else {
      statusDesc.textContent = 'Pausada';
      statusDesc.className = 'status-desc disabled';
    }
  }

  // Cargar estadísticas de la página en primer plano y acumulados
  chrome.runtime.sendMessage({ action: 'GET_STATS' }, (res) => {
    if (res) {
      updateUI(res.enabled, res.pageBlocked, res.totalBlocked);
    }
  });

  // Al cambiar el interruptor
  powerToggle.addEventListener('change', () => {
    chrome.runtime.sendMessage({ action: 'TOGGLE_ADBLOCKER' }, (res) => {
      if (res) {
        chrome.runtime.sendMessage({ action: 'GET_STATS' }, (stats) => {
          if (stats) {
            updateUI(stats.enabled, stats.pageBlocked, stats.totalBlocked);
          }
        });
      }
    });
  });
});
